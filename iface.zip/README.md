DPT-Board-UI
==========

User interface for the DPTechnics DPT-Board. This interface contains
an integrated web javascript editor to run your javascript directly on 
the board.

Control the IO's with a simple button click. A graphical programming 
editor is in the make. 
